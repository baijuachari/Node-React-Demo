Run the following commands

1. npm install 
2. gulp 
3. open index.html in browser